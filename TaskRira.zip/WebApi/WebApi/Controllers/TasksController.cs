﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApi.Data;
using WebApi.Models;

namespace WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TasksController : ControllerBase
    {
        private readonly TasksContext _context;

        public TasksController(TasksContext context)
        {
            _context = context;
        }

        // GET: api/tasks
        [HttpGet]
        public async Task<ActionResult<IEnumerable<TodoTask>>> GetTasks()
        {
            // تمام وظایف را از دیتابیس واکشی می‌کند
            var tasksList = await _context.Tasks.ToListAsync();
            return Ok(tasksList);
        }

        // GET: api/tasks/{id}
        [HttpGet("{id}")]
        public async Task<ActionResult<TodoTask>> GetTask(Guid id)
        {
            var task = await _context.Tasks.FindAsync(id);

            if (task == null)
            {
                return NotFound(); // برگرداندن کد 404 اگر وظیفه‌ای با این شناسه موجود نباشد
            }

            return Ok(task);
        }

        // POST: api/tasks
        [HttpPost]
        public async Task<ActionResult<TodoTask>> CreateTask(TodoTask newTask)
        {
            // ModelState به طور خودکار توسط [ApiController] بررسی می‌شود.
            // در صورت نامعتبر بودن مدل (مثلاً Title خالی)، API به صورت خودکار 400 برمی‌گرداند.

            // مقدار‌دهی Id برای وظیفه جدید
            newTask.Id = Guid.NewGuid();
            newTask.IsCompleted = false; // به صورت پیش‌فرض وظیفه تازه ایجاد شده انجام نشده است

            _context.Tasks.Add(newTask);
            await _context.SaveChangesAsync();

            // برگرداندن 201 Created به همراه شیء ایجاد شده و مسیر دسترسی به آن
            return CreatedAtAction(nameof(GetTask), new { id = newTask.Id }, newTask);
        }

        // PUT: api/tasks/{id}
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTask(Guid id, TodoTask updatedTask)
        {
            if (id != updatedTask.Id)
            {
                // شناسه مسیر با شناسه موجود در بدنۀ درخواست همخوانی ندارد
                return BadRequest("شناسه ارسالی با شناسه وظیفه تطابق ندارد.");
            }

            var existingTask = await _context.Tasks.FindAsync(id);
            if (existingTask == null)
            {
                return NotFound(); // اگر وظیفه‌ای با این شناسه پیدا نشد، 404
            }

            // به‌روزرسانی فیلدهای وظیفه موجود با مقادیر جدید
            existingTask.Title = updatedTask.Title;
            existingTask.Description = updatedTask.Description;
            existingTask.IsCompleted = updatedTask.IsCompleted;
            existingTask.DueDate = updatedTask.DueDate;

            // تلاش برای ذخیره تغییرات در دیتابیس
            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                // در سناریوهای نادر اگر به هر دلیلی هنگام ذخیره خطای همزمانی رخ دهد
                return StatusCode(500, "خطایی در به‌روزرسانی وظیفه رخ داد.");
            }

            // موفقیت در به‌روزرسانی (NoContent: 204)
            return NoContent();
        }

        // DELETE: api/tasks/{id}
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTask(Guid id)
        {
            var task = await _context.Tasks.FindAsync(id);
            if (task == null)
            {
                return NotFound();
            }

            _context.Tasks.Remove(task);
            await _context.SaveChangesAsync();

            // 204 NoContent (عملیات حذف موفق بوده و محتوایی برای بازگشت وجود ندارد)
            return NoContent();
        }
    }
}


