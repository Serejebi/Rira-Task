﻿
using Microsoft.EntityFrameworkCore;
using WebApi.Models;
namespace WebApi.Data
{
    public class TasksContext : DbContext
    {
        public TasksContext(DbContextOptions<TasksContext> options)
            : base(options)
        { }

        // مجموعه وظایف در پایگاه‌داده
        public DbSet<TodoTask> Tasks { get; set; }
    }
}