﻿
using System;
using System.ComponentModel.DataAnnotations;
namespace WebApi.Models
{
    public class TodoTask // Model for a task item
    {
        [Key] // مشخص کردن این ویژگی به عنوان کلید اصلی (اختیاری چون EF براساس نام Id خودکار تشخیص می‌دهد)
        public Guid Id { get; set; }

        [Required(ErrorMessage = "عنوان وظیفه الزامی است.")]
        [MaxLength(200, ErrorMessage = "عنوان وظیفه نمی‌تواند بیش از 200 کاراکتر باشد.")]
        public string Title { get; set; }

        public string Description { get; set; }

        public bool IsCompleted { get; set; }

        [Required(ErrorMessage = "تاریخ سررسید را باید تعیین کنید.")]
        public DateTime DueDate { get; set; }
    }
}
