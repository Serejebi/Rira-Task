﻿using Microsoft.EntityFrameworkCore;
using WebApi.Data;

//var builder = WebApplication.CreateBuilder(args);

//// Add services to the container.

//builder.Services.AddControllers();
//// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
//builder.Services.AddEndpointsApiExplorer();
//builder.Services.AddSwaggerGen();

//var app = builder.Build();

//// Configure the HTTP request pipeline.
//if (app.Environment.IsDevelopment())
//{
//    app.UseSwagger();
//    app.UseSwaggerUI();
//}

//app.UseHttpsRedirection();

//app.UseAuthorization();

//app.MapControllers();

//app.Run();
//--------------------------------------------------
var builder = WebApplication.CreateBuilder(args);

// اضافه کردن سرویس‌های MVC و کانتکست دیتابیس به سیستم DI
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// تنظیم کانتکست دیتابیس با استفاده از رشته اتصال تعریف‌شده
builder.Services.AddDbContext<TasksContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

var app = builder.Build();

// در محیط توسعه، Swagger (رابط کاربری مستندات و تست API) فعال شود
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

// تنظیمات میان‌افزارهای وب
app.UseHttpsRedirection();

app.UseAuthorization();

// ثبت مسیرهای کنترلرها در pipeline
app.MapControllers();

app.Run();